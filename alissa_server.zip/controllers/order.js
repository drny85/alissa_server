const {
    validationResult
} = require('express-validator/check');


exports.addOrder = (req, res, next) => {

    ///const { token, amount, email} = req.body;
    console.log(req.body);

}